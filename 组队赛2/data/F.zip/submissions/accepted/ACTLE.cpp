#include <bits/stdc++.h>
#define F first
#define S second
using namespace std;
typedef long long ll;
typedef pair<int,int> pi;
typedef pair<ll,ll> pl;
typedef vector<int> vi;

const int N = (int)1e6+5;
const int M = 2048;

int n;
ll kk, tar;
pl juds[N]; // unc, expr

vector<ll> fac;
vi shd[N];
ll shd_sp[14][60];

set<int> candi_maxl_v;
vector<pair<int,set<int>>> pt_judges;
map<ll,int> maxl_v;
bool invalid[M];
vi v_adj[M];

int sp[20];
void init();

set<pi> actv_conf;  // conf,num
bool dp_flg[M][14];
ll dp_res[M][14];

vi msk[M], nmsk[M];

map<ll,int>::iterator gen_vec( int idx )
{
    ll rem;
    bool tmp_flg;

    pt_judges.push_back({0,set<int>()});
    maxl_v[juds[idx].F] = pt_judges.size()-1;
    auto tt = maxl_v.find(juds[idx].F);

    for(auto it = candi_maxl_v.begin(); it!=candi_maxl_v.end(); it++)
    {
        rem = kk;
        for(auto s:msk[*it])
            rem /= shd_sp[s][shd[idx][s]];
        if( !rem )
            continue;

        tmp_flg = false;
        for(auto s:nmsk[*it])
        {
            if( rem >= shd_sp[s][shd[idx][s]] )
            {
                tmp_flg = true;
                break;
            }
        }
        if( tmp_flg )
            continue;

        pt_judges.back().S.insert(*it);
        v_adj[*it].push_back(pt_judges.size()-1);
    }

    return tt;
}

void reduce( int ptj_idx )
{
    deque<int> q;
    q.push_back(ptj_idx);

    while( !q.empty() )
    {
        ptj_idx = q.front();
        q.pop_front();

        if( !pt_judges[ptj_idx].S.size() )
            continue;

        auto it = pt_judges[ptj_idx].S.begin(), e = pt_judges[ptj_idx].S.end();
        while( it != e )
        {
            auto t = *(it++);
            for(auto s:v_adj[t])
            {
                pt_judges[s].S.erase(t);
                if( pt_judges[s].F >= pt_judges[s].S.size() )
                    q.push_back(s);
            }
            candi_maxl_v.erase(t);
            invalid[t] = true;
        }
    }
}

int main()
{
    //freopen("Sample.D.txt", "r", stdin);

    init();

    int i,j,k;
    ll cur_tmp;

    k = sp[fac.size()];
    for(i=0;i<k;i++)
    {
        cur_tmp = kk;
        for(auto s:msk[i])
            cur_tmp /= shd_sp[s][shd[n][s]];
        if( !cur_tmp )
            continue;
        candi_maxl_v.insert(i);
    }

    set<pi> to_actv;
    map<pi,ll> mod_lst;
    map<ll,int>::iterator tt;

    actv_conf.insert({0,0});
    dp_flg[0][0] = true;
    dp_res[0][0] = 0LL;

    for(i=0;i<n;i++)
    {
        tt = maxl_v.find(juds[i].F);
        if( tt == maxl_v.end() )
            tt = gen_vec(i);
        else if( pt_judges[tt->S].F >= pt_judges[tt->S].S.size() )
            continue;

        to_actv.clear();
        mod_lst.clear();
        for(auto it = pt_judges[tt->S].S.begin(); it!=pt_judges[tt->S].S.end(); it++)
        {
            for(auto t:actv_conf)
            {
                if( (*it&t.F) == *it )
                    continue;

                k = ( *it | t.F );
                j = t.S + 1;
                cur_tmp = dp_res[t.F][t.S] + juds[i].S;
                if( !dp_flg[k][j] || cur_tmp < dp_res[k][j] )
                {
                    if( !dp_flg[k][j] )
                        to_actv.insert({k,j});

                    auto ttt = mod_lst.find({k,j});
                    if( ttt == mod_lst.end() )
                        mod_lst[{k,j}] = cur_tmp;
                    else if ( cur_tmp < ttt->S )
                        ttt->S = cur_tmp;
                }
            }
        }

        for(auto s:to_actv)
            actv_conf.insert({s.F,s.S});

        for(auto s:mod_lst)
        {
            if( !dp_flg[s.F.F][s.F.S] || s.S < dp_res[s.F.F][s.F.S] )
            {
                dp_flg[s.F.F][s.F.S] = true;
                dp_res[s.F.F][s.F.S] = s.S;
            }
        }

        if( ++pt_judges[tt->S].F >= pt_judges[tt->S].S.size() )
            reduce(tt->S);
    }

    int goal = sp[fac.size()] - 1 ;
    ll cur_min = LLONG_MAX, ttmp;

    if( !goal )
        cur_min = 0LL;

    for(i=0;i<=fac.size();i++)
        if( dp_flg[goal][i] && dp_res[goal][i]*((ll)i) < cur_min )
            cur_min = dp_res[goal][i]*((ll)i);

    if( cur_min < LLONG_MAX )
        printf("%lld\n", cur_min);
    else
        printf("-1\n");

    return 0;
}

inline ll gcd(ll a, ll b)
{
    ll ttr;
    while(b)
        ttr=a%b,a=b,b=ttr;
    return a;
}

vector<ll> prm_t;
bool isprm[500005];
void build_prime_t(), init();

bool comp( const pl &a, const pl &b )
{
    return a.S < b.S;
}
void init()
{
    int i,j,k;
    ll target,tmp;

    for(i=0;i<20;i++)
        sp[i] = 1<<i;

    scanf("%d %lld", &n, &kk);
    for(i=0;i<n;i++)
    {
        scanf("%lld", &juds[i].F);
        target = i ? gcd(target,juds[i].F) : juds[i].F;
    }
    for(i=0;i<n;i++)
        scanf("%lld", &juds[i].S);

    sort(juds,juds+n,comp);

    tar = target;
    build_prime_t();
    for(i=0;i<prm_t.size() && target > 1;i++)
    {
        if( target % prm_t[i] == 0 )
        {
            while( target % prm_t[i] == 0 )
                target /= prm_t[i];
            fac.push_back(prm_t[i]);
        }
    }
    if( target > 1 )
        fac.push_back(target);

    for(i=0;i<fac.size();i++)
    {
        shd_sp[i][0] = 1LL;
        for(j=1;shd_sp[i][j-1]<=(ll)1e12;j++)
            shd_sp[i][j] = shd_sp[i][j-1] * fac[i];
    }

    juds[n].F = tar;
    for(i=0;i<=n;i++)
    {
        for(j=0;j<fac.size();j++)
        {
            shd[i].push_back(0);
            while( juds[i].F % fac[j] == 0 )
                juds[i].F/=fac[j], shd[i][j]++;
        }

        tmp = 1LL;
        for(j=0;j<fac.size();j++)
            if( shd_sp[j][shd[i][j]] <= kk )
                tmp *= shd_sp[j][shd[i][j]];
        juds[i].F = tmp;
    }

    k = sp[fac.size()];
    for(i=0;i<k;i++)
    {
        for(j=0;j<fac.size();j++)
        {
            if( i&sp[j] )
                msk[i].push_back(j);
            else
                nmsk[i].push_back(j);
        }
    }
}

void build_prime_t()
{
    int i,j,k;

    prm_t.push_back(2);
    prm_t.push_back(3);
    for(i=5;i<1000005;i+=2)
    {
        if(!isprm[i>>1])
        {
            prm_t.push_back(i);
            for(j=i;j<1000005;j+=i+i)
                isprm[j>>1] = true;
        }
    }
}
