#include<bits/stdc++.h>
#define N 1001000
#define K 11
using namespace std;
typedef long long ll;
struct tp{
	long long a;
	int e;
	bool operator<(tp x)const{return e<x.e;}
}s[N];
ll gcd(ll x, ll y){
	while(y){
		x%=y;
		swap(x,y);
	}
	return x;
}
vector<int> in[N];
ll dp[K+1][1<<K];
list<int> bs[1<<K];
int main(){
	int n,m=0;
	ll k;
	scanf("%d",&n);
	scanf("%lld",&k);
	ll prm[K];
	int pcnt=0;
	ll g=0,tg;
	for(int i=0;i<n;i++){
		scanf("%lld",&s[i].a);
		g=gcd(g,s[i].a);
	}
	for(int i=0;i<n;i++){
		scanf("%d",&s[i].e);
	}
	tg=g;
	for(ll r=2;r*r<=tg;r++){
		if(tg%r==0){
			prm[pcnt++]=r;
			while(tg%r==0) tg/=r;
		}
	}
	if(tg>1) prm[pcnt++]=tg;
	sort(s,s+n);
	for(int i=0;i<n;i++){
		long long tr=1;
		while((tg=gcd(g,s[i].a))>1){
			tr*=tg;
			s[i].a/=tg;
		}
		s[i].a=tr;
	}
	unordered_map<long long,int> cnt;
	for(int i=0;i<n;i++){
		if(cnt[s[i].a]<pcnt){
			cnt[s[i].a]++;
			s[m++]=s[i];
		}
	}
	n=m;
	/*puts("!");
	printf("%d\n",n);
	for(int i=0;i<n;i++){
		cout<<s[i].a<<" "<<s[i].e<<endl;
	}*/
	for(int i=0;i<=pcnt;i++){
		memset(dp[i],-1,sizeof(dp[i]));
	}
	dp[0][0]=0;
	ll val[1<<K];
	val[0]=1;
	for(int i=0;i<n;i++){
		for(int j=0;j<pcnt;j++){
			val[1<<j]=1;
			while(s[i].a%prm[j]==0){
				val[1<<j]*=prm[j];
				s[i].a/=prm[j];
			}
		}
		for(int j=1;j<(1<<pcnt);j++){
			val[j]=val[j&-j]*val[j^(j&-j)];
		}
		for(int c=pcnt-1;c>=0;c--){
			for(int j=(1<<pcnt)-1;j>0;j--){
				for(int l=j;l>0;l=(l-1&j)){
					if(dp[c][j^l]>=0 && val[l]<=k){
						ll nval=dp[c][j^l]+s[i].e;
						if(dp[c+1][j]<0||nval<dp[c+1][j]) dp[c+1][j]=nval;
					}
				}
			}
		}
	}
	ll ans=-1;
	for(int i=0;i<=pcnt;i++){
		if(dp[i][(1<<pcnt)-1]>=0){
			long long nw=dp[i][(1<<pcnt)-1]*i;
			if(ans<0||nw<ans) ans=nw;
		}
	}
	cout<<ans<<endl;
	return 0;
}