#include<bits/stdc++.h>
#define N 1001000
#define K 11
using namespace std;
typedef long long ll;
struct tp{
	long long a;
	int e;
	bool operator<(tp x)const{return e<x.e;}
}s[N];
ll gcd(ll x, ll y){
	while(y){
		x%=y;
		swap(x,y);
	}
	return x;
}
ll dp[K+1][1<<K];
int trans_cnt[1<<K];
//int trans_lim[1<<K];
int main(){
	time_t st=clock();
	int n,m=0;
	ll k;
	scanf("%d",&n);
	scanf("%lld",&k);
	ll prm[K];
	int pcnt=0;
	ll g=0,tg;
	for(int i=0;i<n;i++){
		scanf("%lld",&s[i].a);
		g=gcd(g,s[i].a);
	}
	for(int i=0;i<n;i++){
		scanf("%d",&s[i].e);
	}
	tg=g;
	for(ll r=2;r*r<=tg;r++){
		if(tg%r==0){
			prm[pcnt++]=r;
			while(tg%r==0) tg/=r;
		}
	}
	if(tg>1) prm[pcnt++]=tg;
	sort(s,s+n);
	unordered_map<long long,int> cnt;
	for(int i=0;i<=pcnt;i++){
		memset(dp[i],-1,sizeof(dp[i]));
	}
	dp[0][0]=0;
	ll val[1<<K];
	val[0]=1;
	/*trans_lim[0]=pcnt+1;
	for(int i=1;i<(1<<pcnt);i++){
		trans_lim[i]=trans_lim[i^(i&-i)]-1;
	}*/
	for(int i=0;i<n;i++){
		vector<int> trans;
		ll tot=1;
		for(int j=0;j<pcnt;j++){
			val[1<<j]=1;
			while(s[i].a%prm[j]==0){
				val[1<<j]*=prm[j];
				s[i].a/=prm[j];
			}
			tot*=val[1<<j];
		}
		if(++cnt[tot]>pcnt) continue;
		for(int j=1;j<(1<<pcnt);j++){
			val[j]=val[j&-j]*val[j^(j&-j)];
			//if(val[j]<=k && trans_cnt[j]<trans_lim[j]){
			if(val[j]<=k && trans_cnt[j]<pcnt){
				trans.push_back(j);
				trans_cnt[j]++;
			}
		}
		for(int c=pcnt-1;c>=0;c--){
			for(int j: trans){
				int pre=((1<<pcnt)-1)^j; //bitmask for "not in j"
				for(int l=pre;l>0;l=(l-1)&pre){
					if(dp[c][l]<0) continue;
					if(dp[c+1][j|l]<0 || dp[c][l]+s[i].e<dp[c+1][j|l]){
						dp[c+1][j|l] = dp[c][l] + s[i].e;
					}
				}
				if(dp[c][0]>=0 && (dp[c+1][j]<0 || dp[c][0]+s[i].e<dp[c+1][j])){
					dp[c+1][j]=dp[c][0]+s[i].e;
				}
			}
		}
	}
	ll ans=-1;
	for(int i=0;i<=pcnt;i++){
		if(dp[i][(1<<pcnt)-1]>=0){
			long long nw=dp[i][(1<<pcnt)-1]*i;
			if(ans<0||nw<ans) ans=nw;
		}
	}
	cout<<ans<<endl;
	fprintf(stderr,"%.2f sec\n",1.0*(clock()-st)/CLOCKS_PER_SEC);
	return 0;
}