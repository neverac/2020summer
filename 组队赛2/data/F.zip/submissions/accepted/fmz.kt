private fun nextLine() = readLine()!!
private fun nextInt() = nextLine().toInt()
private fun nextToks() = nextLine().split(" ")
private fun nextInts() = nextToks().map{it.toInt()}
private fun nextLongs() = nextToks().map{it.toLong()}

data class Senator(var a: Long, var e: Int)

val maxN = 1_000_000

fun gcd(x: Long, y: Long): Long {
    var a = x
    var b = y
    var tmp: Long
    while (b > 0L) {
        tmp = a % b
        a = b
        b = tmp
    }
    return a
}

fun main() {
    val toks = nextToks()
    var n = toks[0].toInt()
    val k = toks[1].toLong()
    val a = nextLongs()
    var g = a.reduce{x, y-> gcd(x,y)}
    val e = nextInts()
    var s = Array<Senator>(n){Senator(a[it], e[it])}
    s.sortBy{it.e}

    // factoring g
    var prime = ArrayList<Long>()
    var rem = g
    if (rem.and(1L) == 0L) {
        prime.add(2L)
        rem /= rem.and(-rem)
    }

    var div = 3L
    while (div * div <= rem) {
        if (rem % div == 0L) {
            prime.add(div)
            while (rem % div == 0L) rem /= div
        }
        div += 2
    }
    if (rem > 1) prime.add(rem)

    val maxK = prime.size
    val mask = 1.shl(maxK) - 1
    var dp = Array<LongArray>(maxK+1){LongArray(1+mask){-1L}}
    var transCnt = IntArray(1+mask){0}

    var cnt = HashMap<Long,Int>()
    var trans = ArrayList<Int>(1+mask)
    dp[0][0] = 0L
    var v = LongArray(1+mask){0}
    v[0] = 1L
    for (ss in s) {
        trans.clear()
        var total = 1L
        for (j in 0 until maxK) {
            v[1 shl j] = 1L
            while (ss.a % prime[j] == 0L) {
                v[1 shl j] *= prime[j]
                ss.a /= prime[j]
            }
            total *= v[1 shl j]
        }
        var x = cnt[total] ?: 0
        cnt[total] = x + 1
        if (x >= maxK) continue

        for (j in 1..mask) {
            v[j] = v[j.and(-j)]*v[j.xor(j.and(-j))]
            if (v[j] <= k && transCnt[j] < maxK) {
                trans.add(j)
                transCnt[j] += 1
            }
        }

        for (c in maxK-1 downTo 0) {
            for (j in trans) {
                val pre = j.xor(mask)
                var l = pre
                while (l > 0) {
                    if (dp[c][l]>=0) {
                        val nv = dp[c][l] + ss.e
                        if (dp[c+1][j or l] < 0) dp[c+1][j or l] = nv
                        else dp[c+1][j or l] = minOf(dp[c+1][j or l], nv)
                    }
                    l = (l-1).and(pre)
                }
                if (dp[c][0] >= 0) {
                    if (dp[c+1][j]<0) dp[c+1][j] = dp[c][0] + ss.e
                    else dp[c+1][j] = minOf(dp[c+1][j], dp[c][0] + ss.e)
                }
            }
        }
    }
    var ans = (0..maxK).filter{dp[it][mask]>=0}
                .map{dp[it][mask]*it}.min() ?: -1L
    println(ans)
}
