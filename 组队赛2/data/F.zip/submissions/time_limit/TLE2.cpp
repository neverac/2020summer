#include <bits/stdc++.h>
#define F first
#define S second
using namespace std;
typedef long long ll;
typedef pair<int,int> pi;
typedef pair<ll,ll> pl;
typedef vector<int> vi;

const int N = (int)1e6+5;
const int M = 2048;

int n;
ll kk, gcdd;
pair<ll,int> juds[N];

int sp[20];
vi msk[M], nmsk[M];
int cnt[M];

void init();

int actv_num;
vi actv_conf[14];  // conf
bool dp_flg[M][14];
ll dp_res[M][14];

vector<ll> fac;
set<int> candi_maxl_v;
vi maxl_v;

ll gcd_fac[20], jud_fac[20];

int main()
{
    //freopen("Sample.D.txt", "r", stdin);

    init();

    int i,j,k,a,b,c;
    ll cur_tmp, rem;

    k = sp[fac.size()];
    for(i=0;i<k;i++)
    {
        cur_tmp = kk;
        for(auto s:msk[i])
            cur_tmp /= gcd_fac[s];
        if( !cur_tmp )
            continue;
        candi_maxl_v.insert(i);
    }

    actv_num = 0;
    actv_conf[0].push_back(0);

    dp_flg[0][0] = true;
    dp_res[0][0] = 0LL;

    for(i=0;i<n;i++)
    {
        if( !candi_maxl_v.size() )
            continue;

        maxl_v.clear();

        juds[i].F /= gcdd;
        for(j=0;j<fac.size();j++)
        {
            jud_fac[j] = gcd_fac[j];
            while( juds[i].F % fac[j] == 0 )
                juds[i].F/=fac[j], jud_fac[j]*=fac[j];
        }

        auto it = candi_maxl_v.begin();
        while( it != candi_maxl_v.end() )
        {
            auto rit = it++;
            auto ss = *rit;

            rem = kk;
            for(auto s:msk[ss])
                rem /= jud_fac[s];
            if( !rem )
                continue;

            if( ++cnt[ss] >= fac.size() )
                candi_maxl_v.erase(rit);

            for(j=0;j<nmsk[ss].size();j++)
                if( jud_fac[nmsk[ss][j]] <= rem )
                    break;
            if( j < nmsk[ss].size() )
                continue;

            maxl_v.push_back(ss);
        }

        if( !maxl_v.size() )
            continue;

        for(a=actv_num;a>=0;a--)
        {
            for(auto t:actv_conf[a])
            {
                for(auto s:maxl_v)
                {
                    if( ( s & t ) == s )
                        continue;

                    k = ( s | t );
                    j = a + 1;
                    cur_tmp = dp_res[t][a] + juds[i].S;

                    if( j > actv_num )
                        actv_num = j;

                    if( !dp_flg[k][j] )
                    {
                        actv_conf[j].push_back(k);
                        dp_flg[k][j] = true;
                        dp_res[k][j] = cur_tmp;
                    }
                    else if( cur_tmp < dp_res[k][j] )
                        dp_res[k][j] = cur_tmp;
                }
            }
        }
    }

    int goal = sp[fac.size()] - 1 ;
    ll cur_min = LLONG_MAX;

    if( !goal )
        cur_min = 0LL;
    for(i=0;i<=fac.size();i++)
        if( dp_flg[goal][i] && 1LL*i*dp_res[goal][i] < cur_min )
            cur_min = 1LL*i*dp_res[goal][i];

    if( cur_min < LLONG_MAX )
        printf("%lld\n", cur_min);
    else
        printf("-1\n");

    return 0;
}

inline ll gcd(ll a, ll b)
{
    ll ttr;
    while(b)
        ttr=a%b,a=b,b=ttr;
    return a;
}

bool comp( const pl &a, const pl &b )
{
    return a.S < b.S;
}
void init()
{
    int i,j,k;
    ll tmp;

    for(i=0;i<20;i++)
        sp[i] = 1<<i;

    scanf("%d%lld", &n, &kk);

    scanf("%lld", &juds[0].F);
    gcdd = juds[0].F;
    for(i=1;i<n;i++)
    {
        scanf("%lld", &juds[i].F);
        gcdd = gcd(gcdd,juds[i].F);
    }
    for(i=0;i<n;i++)
        scanf("%d", &juds[i].S);

    sort(juds,juds+n,comp);

    tmp = gcdd;
    k = 0;
    for(ll ii=2;ii*ii <= tmp;ii++)
    {
        if( tmp % ii == 0 )
        {
            fac.push_back(ii);
            gcd_fac[k] = 1LL;
            while( tmp % ii == 0 )
                tmp /= ii, gcd_fac[k] *= ii;
            k++;
        }
    }
    if( tmp > 1 )
    {
        fac.push_back(tmp);
        gcd_fac[k++] = tmp;
    }

    k = sp[fac.size()];
    for(i=0;i<k;i++)
    {
        for(j=0;j<fac.size();j++)
        {
            if( i&sp[j] )
                msk[i].push_back(j);
            else
                nmsk[i].push_back(j);
        }
    }
}
