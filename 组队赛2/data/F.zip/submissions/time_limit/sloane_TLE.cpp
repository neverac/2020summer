#include <bits/stdc++.h>
#define F first
#define S second
using namespace std;
typedef long long ll;
typedef pair<int,int> pi;
typedef pair<ll,ll> pl;

const int N = (int)1e6;

int n;
ll kk, tar;
pl juds[N]; // unc, expr

vector<ll> fac;
vector<int> shd[N];
ll shd_sp[12][60];

int sp[20];
void init();

set<int> actv_conf;
bool dp_flg[4096][14];
ll dp_res[4096][14];

map<vector<int>,vector<int>> maxl_v;

map<vector<int>,vector<int>>::iterator gen_vec( int idx )
{
    int i,j,k;
    ll rem;

    maxl_v[shd[idx]] = vector<int>();
    auto tt = maxl_v.find(shd[idx]);

    k = sp[fac.size()];
    for(i=0;i<k;i++)
    {
        rem = kk;
        for(j=0;j<fac.size();j++)
            if( i & sp[j] )
                rem /= shd_sp[j][shd[idx][j]];
        if( !rem )
            continue;

        for(j=0;j<fac.size();j++)
            if( ( i & sp[j] ) == 0 && shd[idx][j] )
                if( rem >= shd_sp[j][shd[idx][j]] )
                    break;
        if( j < fac.size() )
            continue;

        tt->S.push_back(i);
    }

    return tt;
}

int main()
{
    //freopen("Sample.D.txt", "r", stdin);

    init();

    int i,j,k,a,b;
    ll cur_tmp;

    vector<int> to_actv;
    vector<pair<pi,ll>> chk_list;

    actv_conf.insert(0);
    dp_flg[0][0] = true;
    dp_res[0][0] = 0LL;

    for(i=0;i<n;i++)
    {
        auto tt = maxl_v.find(shd[i]);
        if( tt == maxl_v.end() )
            tt = gen_vec(i);

        to_actv.clear();
        chk_list.clear();
        for(auto s:tt->S)
        {
            for(auto t:actv_conf)
            {
                k = ( s | t );
                if( !actv_conf.count(k) )
                    to_actv.push_back(k);

                for(j=0;j<=fac.size();j++)
                    if( dp_flg[t][j] )
                        chk_list.push_back({{k,j+1}, dp_res[t][j]+juds[i].S});
            }
        }

        for(auto s:to_actv)
            actv_conf.insert(s);

        for(auto s:chk_list)
        {
            k = s.F.F;
            j = s.F.S;
            if( !dp_flg[k][j] )
            {
                dp_flg[k][j] = true;
                dp_res[k][j] = s.S;
            }
            else if( s.S < dp_res[k][j] )
                dp_res[k][j] = s.S;
        }
    }

    k = sp[fac.size()] - 1 ;
    ll cur_min = LLONG_MAX, ttmp;

    if( actv_conf.count(k) )
    {
        for(j=0;j<=fac.size();j++)
            if( dp_flg[k][j] && dp_res[k][j]*((ll)j) < cur_min )
                cur_min = dp_res[k][j]*((ll)j);
        printf("%lld\n", cur_min);
    }
    else
        printf("-1\n");

    return 0;
}

inline ll gcd(ll a, ll b)
{
    ll ttr;
    while(b)
        ttr=a%b,a=b,b=ttr;
    return a;
}

vector<ll> prm_t;
bool isprm[500005];
void build_prime_t(), init();

bool comp( const pl &a, const pl &b )
{
    return a.S < b.S;
}
void init()
{
    int i,j,k;
    ll target,tmp;

    for(i=0;i<20;i++)
        sp[i] = 1<<i;

    scanf("%d %lld", &n, &kk);
    for(i=0;i<n;i++)
    {
        scanf("%lld", &juds[i].F);
        target = i ? gcd(target,juds[i].F) : juds[i].F;
    }
    for(i=0;i<n;i++)
        scanf("%lld", &juds[i].S);

    sort(juds, juds+n, comp);

    tar = target;
    build_prime_t();
    for(i=0;i<prm_t.size() && target > 1;i++)
    {
        if( target % prm_t[i] == 0 )
        {
            while( target % prm_t[i] == 0 )
                target /= prm_t[i];
            fac.push_back(prm_t[i]);
        }
    }
    if( target > 1 )
        fac.push_back(target);

    for(i=0;i<fac.size();i++)
    {
        shd_sp[i][0] = 1LL;
        for(j=1;shd_sp[i][j-1]<=(ll)1e13;j++)
            shd_sp[i][j] = shd_sp[i][j-1] * fac[i];
    }

    for(i=0;i<n;i++)
    {
        for(j=0;j<fac.size();j++)
        {
            shd[i].push_back(0);
            while( juds[i].F % fac[j] == 0 )
                juds[i].F/=fac[j], shd[i][j]++;
        }
    }
}

void build_prime_t()
{
    int i,j,k;

    prm_t.push_back(2);
    prm_t.push_back(3);
    for(i=5;i<1000005;i+=2)
    {
        if(!isprm[i>>1])
        {
            prm_t.push_back(i);
            for(j=i;j<1000005;j+=i+i)
                isprm[j>>1] = true;
        }
    }
}
